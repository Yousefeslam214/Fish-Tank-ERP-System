export { default } from './FishTypeManagementEnhanced';
