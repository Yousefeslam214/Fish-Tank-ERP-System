import { useState, useEffect } from "react";
import { User, Farm } from "../types";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";

interface Props {
  user: User;
  selectedFarm: Farm | null;
}

export default function Farms({ user }: Props) {
  const [farms, setFarms] = useState<Farm[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Connect to the API
    const fetchFarms = async () => {
      try {
        const response = await fetch("/api/v1/farms");
        const json = await response.json();

        if (json.success) {
          // We only take the array from "data"
          setFarms(json.data);
        }
      } catch (error) {
        console.error("Failed to fetch farms:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchFarms();
  }, []);

  return (
    <div className="p-6 bg-[#F9FAFB] min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-semibold text-gray-900">Farms</h1>
          <p className="text-sm text-gray-500">
            Welcome back, {user?.name ?? "User"}
          </p>
        </div>

        <button className="px-4 py-2 bg-[#088395] text-white rounded-lg text-sm hover:bg-[#0A4D68] transition">
          Add Farm
        </button>
      </div>

      {/* Farms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <p className="text-gray-500 italic">Loading farms...</p>
        ) : (
          farms.map((farm) => (
            <Card
              key={farm.id}
              className="bg-white shadow-sm hover:shadow-md transition"
            >
              <CardHeader className="pb-3">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-lg font-bold text-[#0A4D68]">
                      {farm.name}
                    </CardTitle>
                    <p className="text-[10px] text-gray-400 font-mono">
                      ID: {farm.id}
                    </p>
                  </div>

                  {/* Uses the isActive boolean for styling */}
                  <Badge
                    className={`${
                      farm.isActive ? "bg-green-600" : "bg-gray-400"
                    } text-white text-[10px] px-2 py-0.5`}
                  >
                    {farm.isActive ? "ACTIVE" : "INACTIVE"}
                  </Badge>
                </div>

                <p className="text-sm text-gray-600 mt-2">
                  {farm.location || "Location not provided"}
                </p>
              </CardHeader>

              <CardContent>
                <div className="bg-gray-50 p-3 rounded-lg border border-dashed border-gray-200">
                  <p className="text-xs text-gray-400 text-center italic">
                    Farm details loaded successfully.
                  </p>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
