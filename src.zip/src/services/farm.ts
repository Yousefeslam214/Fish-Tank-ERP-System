export interface farms{
    id: string;
    name: string;
    location: string;
    isActive: boolean;
}